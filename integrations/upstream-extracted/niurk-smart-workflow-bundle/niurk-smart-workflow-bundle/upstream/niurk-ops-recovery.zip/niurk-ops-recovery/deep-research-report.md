# Récupération et redéploiement non destructif d’un cluster Ceph sur rhiz-loes

## Résumé exécutif

Ce rapport décrit une stratégie **rigoureuse, modulaire et non destructive** pour remettre en service un cluster Ceph existant dont le **FSID est `b7b96750-2307-11f1-b1f3-80e82cc9d3f8`**, en ciblant l’exploitation depuis le nœud maître **`rhiz-loes`** (tel qu’implémenté dans le bundle fourni). L’objectif est un **redéploiement logique** des composants (MON, MGR, OSD, nœuds d’administration) en **préservant la configuration et les données**, en s’appuyant prioritairement sur l’outillage **cephadm / orchestrator** (recommandé hors Kubernetes), et en évitant toute opération de type *zap* ou purge. citeturn6search18turn5view0turn7search21

La méthode proposée s’ordonne autour de modules indépendants : **préflight système**, **tests réseau**, **sauvegardes**, **réactivation locale des daemons via systemd/cephadm**, **ré-inscription orchestrator**, **re-application des placements MON/MGR**, **distribution contrôlée de `ceph.conf` et du keyring admin** via le label `_admin`, puis **contrôles post-restauration** (santé, quorum, OSD up/in, PG). citeturn5view0turn6search15turn7search21

Un **nouveau bundle téléchargeable** a été généré, intégrant cette chaîne d’automatisation (scripts, checks, documentation, structure et checksum).  
**Bundle** : [Télécharger niurk-ops-ceph-recover-rhiz-loes-fsid-b7b96750-2307-11f1-b1f3-80e82cc9d3f8-20260407T120000+0200.zip](sandbox:/mnt/data/niurk-ops-ceph-recover-rhiz-loes-fsid-b7b96750-2307-11f1-b1f3-80e82cc9d3f8-20260407T120000+0200.zip)  
**SHA-256** : `3dd97e4096cb4b7035e3979e6332308991630ed535ebf96463efda3bfa9bc14a`

## Contexte, hypothèses et périmètre

Le plan présenté vise explicitement un cluster **déjà existant** ; il ne s’agit pas de recréer un cluster neuf. La récupération « non destructive » présuppose donc que **l’état persistant critique** existe encore quelque part (notamment au moins un store MON intact ou sauvegardé), car le MON porte des informations d’état et d’authentification indispensables (maps, authdb). Dans les workflows cephadm, les données/états des daemons se trouvent typiquement sous `/var/lib/ceph/<fsid>/…`. citeturn5view0

Hypothèses explicites (éléments non fournis par la demande et donc à confirmer sur site) :

- **Version Ceph** : non spécifiée. Si vous utilisez **cephadm**, il faut un Ceph **Octopus (v15.2.0) ou ultérieur**, car cephadm ne supporte pas les versions plus anciennes. citeturn4search22  
- **Mode de gestion** : on suppose une gestion via **cephadm/orchestrator** (plutôt que *ceph-deploy* ou *ceph-ansible* historique), car cephadm fournit nativement les primitives de contrôle/redeploy par daemon et des checks dédiés (host checks, config checks). citeturn5view0turn7search21  
- **Accès** : accès SSH depuis `rhiz-loes` vers tous les hôtes, et privilèges root/sudo sur les hôtes (passwordless sudo recommandé avec cephadm, notamment si l’utilisateur SSH n’est pas root). citeturn4search9turn5view0  
- **Rook** : hors périmètre sauf si votre Ceph est opéré dans Kubernetes. Rook est un opérateur Kubernetes ; cephadm est précisément conçu comme couche d’installation/gestion robuste **hors Kubernetes**. citeturn2search17turn6search18  
- **Topologie réseau** : non spécifiée dans la demande ; le bundle suggère un réseau Ceph dédié et des contrôles WireGuard, mais cela doit être validé (interfaces, MTU, règles firewall, résolution de noms).

Hôtes Ceph repérés dans l’inventaire du bundle (à revalider sur site) : `rhiz-loes`, `rhiz-ueth`, `rhiz-woute`, `factau-rhiz`, `exosystem`, `sigmo-rhiz`, `ark-rhiz`, `eliosys-rhiz` (rôles MON/MGR/OSD/_admin selon l’inventaire fourni).

## Préconditions et mesures de sécurité

La priorité est d’éviter toute perte de configuration (et, par ricochet, toute perte de capacité à authentifier/réintégrer des daemons). Ce cadre de sécurité repose sur trois piliers.

Conservation de la configuration et des keyrings  
- Un cluster cephadm s’appuie sur `/etc/ceph` pour l’exécution des daemons, et peut également conserver des copies gérées dans `/var/lib/ceph/<fsid>/config` (cephadm-only). Il est recommandé d’avoir `ceph.conf` et `client.admin` sur tout hôte d’administration (label `_admin`). citeturn5view0turn6search2turn6search15  
- Les keyrings doivent typiquement être présents sous `/etc/ceph` (ex. `ceph.client.admin.keyring` en Octopus+). citeturn6search8turn6search1  

Interdits opérationnels pendant une récupération non destructive  
- Interdire les opérations de purge et *zap*, explicitement destructrices :  
  - `cephadm rm-cluster --zap-osds` (purge locale + wipe) est **à proscrire**. citeturn1search19  
  - `ceph orch host drain --zap-osd-devices` et variantes *zap* peuvent effacer des devices OSD pendant une opération de maintenance ; cela est hors-scope d’une récupération « sans effacer ». citeturn7search17  

Préflight cephadm et checks de cohérence  
- cephadm fournit des checks intégrés, notamment `ceph cephadm check-host <hostname>` (runtime conteneur + time sync, etc.) et des **config-checks** (MTU, membership réseau, version Ceph, kernel…). citeturn5view0  
- Si vous devez manipuler les MON, évitez la modification/injection manuelle de monmap si vous êtes en contexte cephadm ; la documentation recommande plutôt de déployer/remplacer les MON via orchestrator (et de passer en mode unmanaged si nécessaire). citeturn7search2turn4search26  

Mesures de rollback (sans effacement)  
Le rollback « propre » consiste à restaurer **les fichiers** et **les métadonnées d’intégration** depuis des backups, plutôt qu’à purger. Les constructs cephadm/orchestrator (labels `_admin`, hosts gérés, placements mon/mgr) sont réversibles via les commandes orchestrator, et la configuration locale `/etc/ceph` peut être restaurée depuis les archives (cf. module backup). citeturn5view0turn7search21  
Pour automatiser la gestion d’échec et de réversibilité côté orchestration (Ansible), utilisez des blocs `block`/`rescue`/`always` pour encapsuler les étapes critiques et déclencher un rollback d’artefacts (restauration de fichiers) si un invariant échoue. citeturn0search11  

## Conception du bundle d’automatisation

Le bundle révisé met l’accent sur l’indépendance, l’idempotence et la séparation des responsabilités. Le socle vise à fonctionner en deux temps :

- **Host-local** (utile même si le cluster est « down ») : checks système, backups, réactivation des services via `cephadm unit` / systemd.
- **Cluster-wide** (nécessite qu’au moins un MON/MGR soit opérationnel) : orchestrator (`ceph orch …`), placements, labels, config-checks, vérifications.

### Cartographie rôles ↔ hôtes

```mermaid
graph TD
  MON((mon)) --> rhiz_loes[rhiz-loes]
  MON --> rhiz_ueth[rhiz-ueth]
  MON --> rhiz_woute[rhiz-woute]
  MON --> factau_rhiz[factau-rhiz]
  MON --> exosystem[exosystem]

  MGR((mgr)) --> rhiz_loes
  MGR --> rhiz_ueth
  MGR --> rhiz_woute

  OSD((osd)) --> rhiz_loes
  OSD --> rhiz_ueth
  OSD --> rhiz_woute
  OSD --> factau_rhiz
  OSD --> sigmo_rhiz[sigmo-rhiz]
  OSD --> ark_rhiz[ark-rhiz]
  OSD --> exosystem
  OSD --> eliosys_rhiz[eliosys-rhiz]

  ADMIN((_admin)) --> rhiz_loes
  ADMIN --> rhiz_ueth
  ADMIN --> exosystem
```

### Table de comparaison des modules

| Module | Responsabilité | Entrées | Sorties/artefacts | Idempotence | Risque config |
|---|---|---|---|---|---|
| `80-ceph-recover-preflight.sh` | Checks OS, time sync, runtime conteneur, présence `/etc/ceph`, détection FSID | `CEPH_TARGET_FSID` | Logs (stdout) | Oui (read-only) | Faible |
| `81-ceph-recover-network-check.sh` | Ping inter-hôtes, tests ports MON (3300/6789), état WireGuard (si présent) | Inventaire `directives/hosts.yaml` | Logs | Oui (read-only) | Faible |
| `82-ceph-recover-backup.sh` | Backups « light/full » (config/keyrings + diagnostics + LVM) | mode `light|full` | `/var/tmp/niurk-ceph-recover/backups/...` + `SHA256SUMS` | Oui (nouveau timestamp) | Faible |
| `83-ceph-recover-host.sh` | Démarrage MON/MGR/OSD via `cephadm unit` (non destructive) | `mon|mgr|osd|all` | Logs + backup light auto | Oui (start répété OK) | Faible |
| `84-ceph-recover-orchestrator.sh` | Ré-inscription hosts, placements MON/MGR, labels `_admin`, host checks | cluster up + `ceph` | État orchestrator mis à jour | Majoritairement (skip si déjà présent) | Moyen (changement orchestrator) |
| `85-ceph-recover-verify.sh` | Vérification post-restore (`ceph -s`, health, orch, osd, pg) | cluster up + `ceph` | Logs | Oui (read-only) | Faible |
| `recover-cluster.sh` | Workflow cluster complet (push, préflight/backup, start MON/MGR/OSD, orchestrator, verify) | `rhiz-loes` | Exécution segmentée + logs | Oui (ré-exécutable) | Moyen (pilotage global) |

Points d’architecture notables (appuyés sur la documentation) :
- cephadm s’appuie sur SSH pour piloter les hôtes et déployer/monitorer des daemons conteneurisés. citeturn4search30turn6search18  
- L’ajout d’hôtes dans un cluster cephadm implique la présence de la clé publique du cluster (ex. `/etc/ceph/ceph.pub`) dans `authorized_keys` (par défaut root), avec une possibilité de configurer un utilisateur non-root (`ceph cephadm set-user <user>`) à condition d’avoir du sudo sans mot de passe. citeturn6search7turn4search9turn4search16  
- Le label `_admin` déclenche la distribution de `ceph.conf` et du keyring `client.admin` sur les hôtes d’admin, ce qui réduit le risque de dérive de configuration locale. citeturn5view0turn6search29turn6search15  
- L’action orchestrator **`redeploy`** (si utilisée) régénère structure de répertoire, fichiers de config, unit-files et redémarre systemd pour un daemon donné. citeturn7search21  

### Workflow d’automatisation

```mermaid
flowchart TD
  A[Master: rhiz-loes] --> B[Préflight + checks réseau]
  B --> C[Push bundle + préflight/backup sur tous les hôtes]
  C --> D[Relancer MON via cephadm unit]
  D --> E[Relancer MGR via cephadm unit]
  E --> F[Relancer OSD via cephadm unit]
  F --> G[Orchestrator: host add + placements mon/mgr]
  G --> H[Labels _admin + check-host/config-check]
  H --> I[Vérifications post-restore]
  I --> J[Pack bundle + checksum]
```

## Procédure de restauration pas à pas

La procédure est proposée en deux variantes : **cluster-wide** (recommandée) et **par hôte** (si vous devez opérer manuellement).

### Variante cluster-wide depuis rhiz-loes

Pré-requis à confirmer avant exécution :
- `rhiz-loes` dispose de `/etc/ceph/ceph.conf` et du keyring admin (`/etc/ceph/ceph.client.admin.keyring`) ou d’un mécanisme équivalent de distribution via `_admin`. citeturn6search8turn5view0  
- Les prérequis cephadm minimaux (container runtime + time sync) sont satisfaits sur les hôtes, sinon `ceph cephadm check-host` signalera `CEPHADM_HOST_CHECK_FAILED`. citeturn5view0  

Commandes :

```bash
# 1) Décompression du bundle sur rhiz-loes
unzip niurk-ops-ceph-recover-rhiz-loes-fsid-b7b96750-2307-11f1-b1f3-80e82cc9d3f8-20260407T120000+0200.zip
cd niurk-ops_v16-ceph-recover

# 2) Exécution du workflow complet (non destructif)
sudo ./bin/exosys.sh ceph-recover-cluster
```

Ce workflow utilise la logique cephadm/systemd via `cephadm unit ... start` (commande dédiée au contrôle des unités systemd des daemons). citeturn7search19turn7search27  
Il tente ensuite une remise en cohérence orchestrator (ré-inscription des hosts, placements, label `_admin`) et active les checks cephadm. citeturn5view0turn7search32turn6search15  
En cas de doute, surveillez les logs cephadm via le canal `cephadm`. citeturn4search12turn5view0  

### Variante par hôte (si action manuelle requise)

L’objectif est de démarrer dans l’ordre **MON → MGR → OSD**, en évitant de « brutaliser » la disponibilité (notamment redémarrages massifs d’OSD). La documentation Ceph rappelle qu’il peut être risqué de redémarrer un service OSD en masse sans prendre en compte les failure domains. citeturn7search1

#### rhiz-loes (master, _admin, mon, mgr, osd)

```bash
sudo ./bin/exosys.sh ceph-recover-preflight
sudo ./bin/exosys.sh ceph-recover-backup light

sudo ./bin/exosys.sh ceph-recover-host mon
sudo ./bin/exosys.sh ceph-recover-host mgr
sudo ./bin/exosys.sh ceph-recover-host osd

# cluster-wide, seulement après retour d’un MON/MGR
sudo ./bin/exosys.sh ceph-recover-orchestrator
sudo ./bin/exosys.sh ceph-recover-verify
```

#### rhiz-ueth (_admin, mon, mgr, osd)

```bash
sudo ./bin/exosys.sh ceph-recover-preflight
sudo ./bin/exosys.sh ceph-recover-backup light
sudo ./bin/exosys.sh ceph-recover-host mon
sudo ./bin/exosys.sh ceph-recover-host mgr
sudo ./bin/exosys.sh ceph-recover-host osd
```

#### rhiz-woute (mon, mgr, osd)

```bash
sudo ./bin/exosys.sh ceph-recover-preflight
sudo ./bin/exosys.sh ceph-recover-backup light
sudo ./bin/exosys.sh ceph-recover-host mon
sudo ./bin/exosys.sh ceph-recover-host mgr
sudo ./bin/exosys.sh ceph-recover-host osd
```

#### factau-rhiz (mon, osd)

```bash
sudo ./bin/exosys.sh ceph-recover-preflight
sudo ./bin/exosys.sh ceph-recover-backup light
sudo ./bin/exosys.sh ceph-recover-host mon
sudo ./bin/exosys.sh ceph-recover-host osd
```

#### exosystem (_admin, mon, osd)

```bash
sudo ./bin/exosys.sh ceph-recover-preflight
sudo ./bin/exosys.sh ceph-recover-backup light
sudo ./bin/exosys.sh ceph-recover-host mon
sudo ./bin/exosys.sh ceph-recover-host osd
```

#### sigmo-rhiz (osd)

```bash
sudo ./bin/exosys.sh ceph-recover-preflight
sudo ./bin/exosys.sh ceph-recover-backup light
sudo ./bin/exosys.sh ceph-recover-host osd
```

#### ark-rhiz (osd)

```bash
sudo ./bin/exosys.sh ceph-recover-preflight
sudo ./bin/exosys.sh ceph-recover-backup light
sudo ./bin/exosys.sh ceph-recover-host osd
```

#### eliosys-rhiz (osd)

```bash
sudo ./bin/exosys.sh ceph-recover-preflight
sudo ./bin/exosys.sh ceph-recover-backup light
sudo ./bin/exosys.sh ceph-recover-host osd
```

Si vous devez démarrer/arrêter un daemon spécifique via systemd, les guides opérateurs expliquent que les daemons sont pilotables via systemd et que vous pouvez lister les unités `ceph*` sur un hôte pour identifier le bon service. citeturn7search3turn7search19  

## Validation réseau et vérifications post-restauration

### Tests réseau recommandés

Tests « externes » (avant cluster up) :
- Reachability (ping) sur l’adresse Ceph de chaque hôte (réseau public/cluster selon votre design).
- Ports MON : vérifier l’écoute sur **3300 (msgr2)** et **6789 (msgr1)** côté MON, et l’absence de blocage firewall. Les guides firewall/ports Ceph vous donnent la base d’ouverture nécessaire (MON/OSD). citeturn1search18turn1search6  

Tests « internes » (après cluster up, via cephadm) :
- `ceph cephadm check-host <hostname>` pour valider runtime conteneur et synchronisation temporelle. citeturn5view0  
- Activation et lecture des config-checks : `ceph cephadm config-check status` et `ceph cephadm config-check ls` (MTU, link speed, membership réseau public/cluster, cohérence versions). citeturn5view0  

### Vérifications post-restore

Le standard minimal est :
- `ceph -s` et `ceph health detail` pour vérifier quorum et alertes.  
- `ceph orch status`, `ceph orch host ls`, `ceph orch ps` pour l’état orchestrator et les daemons. citeturn7search10turn7search32  
- `ceph osd tree`, `ceph osd stat`, `ceph pg stat`, `ceph df` pour l’état data-plane.  
- Surveiller les logs cephadm : `ceph -W cephadm`. citeturn4search12  

Le bundle encapsule ces contrôles dans `ceph-recover-verify`. En cas de daemons « stray » ou hôtes non gérés, cephadm expose des health checks dédiés et recommande de (re)ajouter les hosts via `ceph orch host add`. citeturn5view0  

## Packaging, exécution et structure du bundle

### Convention de nommage recommandée

Pour distinguer clairement cluster, FSID et date :

- `niurk-ops-ceph-recover-<cluster-or-group>-fsid-<fsid>-<YYYYMMDDThhmmss±TZ>.zip`

Exemple concret (bundle généré) :
- `niurk-ops-ceph-recover-rhiz-loes-fsid-b7b96750-2307-11f1-b1f3-80e82cc9d3f8-20260407T120000+0200.zip`

### Arborescence attendue (extrait)

```
niurk-ops_v16-ceph-recover/
  bin/
    exosys.sh
    exosys-remote.sh
  directives/
    hosts.yaml
    ceph-recovery.yaml
  docs/
    CEPH-RECOVERY-RHIZ-LOES.md
  modules/
    80-ceph-recover-preflight.sh
    81-ceph-recover-network-check.sh
    82-ceph-recover-backup.sh
    83-ceph-recover-host.sh
    84-ceph-recover-orchestrator.sh
    85-ceph-recover-verify.sh
    recover-cluster.sh
```

### Création de checksum et packaging

Si vous devez reconstruire un zip depuis un répertoire de travail :

```bash
# À la racine du répertoire qui contient niurk-ops_v16-ceph-recover/
zip -r niurk-ops-ceph-recover-rhiz-loes-fsid-b7b96750-2307-11f1-b1f3-80e82cc9d3f8-YYYYMMDDThhmmss+ZZZZ.zip niurk-ops_v16-ceph-recover

sha256sum niurk-ops-ceph-recover-*.zip > SHA256SUMS
```

Les modules de backup produisent aussi des `SHA256SUMS` localement pour les artefacts collectés sur chaque hôte (`/var/tmp/niurk-ceph-recover/backups/...`).

### Table des identifiants, privilèges et secrets requis

| Opération | Où | Identité | Privilèges requis | Secrets requis |
|---|---|---|---|---|
| Préflight/Network check | master & hôtes | SSH user (ex. root ou user inventaire) | root/sudo local | Aucun |
| Backup (light/full) | chaque hôte | root | lecture `/etc/ceph`, `lvm`, etc | Aucun (mais fichiers sensibles copiés) |
| Démarrage services via `cephadm unit` | chaque hôte | root | root | Aucun (mais accès aux stores/dirs) |
| Orchestrator host add / apply | master (_admin) | `ceph` CLI | accès `client.admin` (ou équivalent) | `ceph.conf` + `ceph.client.admin.keyring` citeturn6search8turn6search1 |
| Distribution clé SSH cephadm | master → hôtes | user cephadm (root ou non-root) | sudo sans mot de passe conseillé | `/etc/ceph/ceph.pub` ou `ceph cephadm get-pub-key` citeturn6search7turn4search9 |

### Checklist pré/post tâches

| Moment | Tâche | Critère d’acceptation |
|---|---|---|
| Avant | Confirmer FSID cible et présence d’au moins un store MON intact | FSID détecté cohérent, backups possibles citeturn5view0 |
| Avant | Vérifier accès SSH + sudo sur tous les hôtes | `ssh` OK, `sudo -n true` OK si non-root citeturn4search9turn4search16 |
| Avant | Vérifier runtime conteneur + time sync | `ceph cephadm check-host` passe ou préflight local OK citeturn5view0 |
| Pendant | Exécuter backups light partout (full sur MON si possible) | Archives et `SHA256SUMS` produits |
| Pendant | Démarrer MON puis MGR puis OSD | Quorum MON, MGR actif, OSDs progressent vers up/in citeturn7search27turn7search5 |
| Après | Ré-inscrire orchestrator + placements + `_admin` | `ceph orch host ls`, services cohérents, `_admin` distribue config/keyring citeturn6search15turn5view0turn7search16 |
| Après | Vérifier santé et data-plane | `ceph -s`, `health detail`, `pg stat`, `osd tree` acceptables |
| Après | Surveiller logs cephadm | `ceph -W cephadm` sans erreurs répétées citeturn4search12 |

