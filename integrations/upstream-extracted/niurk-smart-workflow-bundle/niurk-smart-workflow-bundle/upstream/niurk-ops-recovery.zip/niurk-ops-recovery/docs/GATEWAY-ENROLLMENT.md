# Gateway enrollment and remote config

The bundle includes token generation and a callback stub:

- `gateway-token-generate` produces a one-time onboarding token JSON artifact
- `gateway-remote-config` posts node metadata to the configured remote callback

When the token name matches an inventory host such as `ark-rhiz`, the generated JSON now includes:

- the inventory profile and roles
- the local-net SSH target
- the gateway endpoint `rhiz-arch.afrho.net`
- the remote config callback used by the bundle

Example:

```bash
sudo ./bin/exosys.sh gateway-token-generate ark-rhiz
```

This is scaffolding: connect it to your real app-gateway service before production use.
