# Ceph Recovery Runbook (FSID b7b96750-2307-11f1-b1f3-80e82cc9d3f8)

This bundle is **safe-by-default**:
- No disk zapping / no config erasure unless you explicitly opt in.
- Primary execution host (master): **rhiz-loes**.
- Target cluster FSID: **b7b96750-2307-11f1-b1f3-80e82cc9d3f8**.

## 0) Prepare on rhiz-loes

```bash
cd ~/niurk-ops
cp env.example .env
# IMPORTANT (recovery safe default):
sed -i 's/^I_UNDERSTAND_DISK_WILL_BE_WIPED=.*/I_UNDERSTAND_DISK_WILL_BE_WIPED=no/' .env

# If you are running on a different master host, set:
# export RECOVERY_MASTER_HOST=<host>
# export RECOVERY_FSID=b7b96750-2307-11f1-b1f3-80e82cc9d3f8
```

Confirm the key env values match your network:
- `CEPH_BOOTSTRAP_MON_IP`
- `CEPH_PUBLIC_NETWORK`
- `CEPH_CLUSTER_NETWORK`

## 1) Non-destructive preflight checks

```bash
sudo ./modules/11-system-check.sh
sudo ./modules/12-network-check.sh
```

## 2) Re-sync hosts (remote config by host)

This step:
- pushes this bundle to each host in `directives/hosts.yaml`
- runs prereqs
- applies WireGuard using a host-specific directive file if present: `directives/wg-ceph-operator.<host>.yaml`
- applies host profile

```bash
sudo RECOVERY_APPLY_REMOTE_CONFIG=yes ./modules/13-remote-config-by-host.sh
```

## 3) Verify we are targeting the right cluster FSID

```bash
sudo ./modules/14-ceph-fsid-verify.sh
```

## 4) Recover Ceph control plane (mon/mgr/admin)

Safe-by-default behavior:
- restarts `cephadm`
- attempts to start local systemd daemons for the target FSID
- **does not bootstrap** unless explicitly allowed

```bash
sudo ./modules/15-ceph-redeploy-safe.sh
```

If the node has no `/etc/ceph/ceph.conf` and `cephadm ls` does not show the FSID, and you *intentionally* want to try bootstrap-with-fsid (last resort):

```bash
sudo RECOVERY_ALLOW_BOOTSTRAP=yes ./modules/15-ceph-redeploy-safe.sh
```

## 5) Restore hosts + storage (OSDs)

This step:
- prepares SSH/sudo access per host
- enrolls hosts in `ceph orch`
- refreshes devices
- applies `directives/osd-spec.yaml` (no zapping)

```bash
sudo ./modules/16-ceph-hosts-and-storage-restore.sh
```

## 6) One-shot full recovery (recommended)

```bash
sudo ./modules/recover-cluster.sh
```

## 7) Validation commands

```bash
ceph -s
ceph health detail
ceph orch ps
ceph orch host ls
ceph orch device ls
ceph osd tree
ceph df
```
