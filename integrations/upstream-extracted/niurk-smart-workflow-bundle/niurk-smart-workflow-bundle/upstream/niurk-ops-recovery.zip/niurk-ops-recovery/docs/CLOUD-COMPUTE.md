# Cloud Compute Profile

This bundle models `ark-rhiz` as the compute and bridge host for `niurk-42`, while `niurk-24` on `sigmo-rhiz` stays the applicative edge and sync surface.

## Host

- host: `ark-rhiz`
- LAN IP: `192.168.0.40`
- WireGuard / Ceph address: `10.42.0.40`
- role: Ceph-backed libvirt hypervisor with shared CPU, GPU, and storage capacity plus the `br-rhiz` bridge for `niurk-42`
- gateway reachability: `rhiz-arch.afrho.net`

## Ubuntu VMs

- `niurk-24`: applicative `/rhiz` edge on `sigmo-rhiz`
- `niurk-42`: llama-gpu, distributed-compute, BI, and Mongo sync node on `ark-rhiz`
- `niurk-43`: hypergraph redundancy and control node on `rhiz-woute`

The niurk guests are intended to:

- join the Ceph-backed storage plane
- participate in the Ubuntu LXD/LXC cluster
- contribute to Docker Swarm placement
- preserve redundancy between `niurk-24`, `niurk-42`, and `niurk-43`

## Integration Surface

- `niurk-24` should reach `niurk-42` over the routed or bridged `192.168.0.0/24` path
- `niurk-42` should expose `11434`, `8013`, `38080`, `27017`, and `8444` on the host bridge path
- `open-webui` and gateway relays should prefer `http://niurk-42:11434`
- trusted handshake and callback publication should continue to flow through `https://rhiz-arch.afrho.net`

## Enrollment

Generate a host-aware token artifact for local automation:

```bash
./bin/exosys.sh gateway-token-generate niurk-24
```

Then render and validate the integration bundle:

```bash
./modules/64-cluster-integration-render.sh
./modules/65-cluster-integration-check.sh
python3 /cloud-compute/build_bundle.py
```

The generated artifacts include the inventory profile, local-net SSH target, bridge and route plans, Ceph and WireGuard surfaces, trusted handshake payloads, and the projected cloud-compute bundle for `rhiz-arch.afrho.net`.
