#!/usr/bin/env bash
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"
load_env
need_cmd python3
have_py_yaml || die "Missing PyYAML. Install python3-pyyaml / python3-yaml."

out_dir="$(generated_dir)/cluster-integration"
mkdir -p "$out_dir"

python3 - "$(cluster_integration_file)" "$out_dir" "${CEPH_MON_HOSTS:-}" <<'PY'
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml


directive_path = Path(sys.argv[1])
out_dir = Path(sys.argv[2])
ceph_mon_hosts = [item.strip() for item in sys.argv[3].split(",") if item.strip()]

with directive_path.open("r", encoding="utf-8") as handle:
    payload = yaml.safe_load(handle) or {}
cluster = payload.get("cluster_integration") or {}
topology = cluster.get("topology") or {}
services = cluster.get("services") or {}
ceph = cluster.get("ceph") or {}

app_vm = topology.get("applicative_vm") or {}
compute_host = topology.get("compute_host") or {}
compute_vm = topology.get("compute_vm") or {}

network_dir = out_dir / "network"
ceph_dir = out_dir / "ceph"
trust_dir = out_dir / "trust"
network_dir.mkdir(parents=True, exist_ok=True)
ceph_dir.mkdir(parents=True, exist_ok=True)
trust_dir.mkdir(parents=True, exist_ok=True)

bridge_name = compute_host.get("bridge_name", "br-rhiz")
bridge_parent = compute_host.get("bridge_parent", "eno1")
bridge_cidr = compute_host.get("lan_addr", "192.168.0.40/24")
bridge_subnet = compute_host.get("bridge_subnet", "192.168.0.0/24")
cluster_iface = app_vm.get("cluster_iface", "enp7s0")
cluster_addr = app_vm.get("cluster_addr", "10.200.0.27/24")
cluster_gateway = app_vm.get("cluster_gateway", "10.200.0.1")
compute_vm_addr = compute_vm.get("lan_addr", "192.168.0.142/24")

(network_dir / f"{bridge_name}.nmconnection").write_text(
    "\n".join(
        [
            "[connection]",
            f"id={bridge_name}",
            "type=bridge",
            f"interface-name={bridge_name}",
            "autoconnect=true",
            "",
            "[bridge]",
            "stp=false",
            "",
            "[ipv4]",
            "method=manual",
            f"address1={bridge_cidr}",
            "",
            "[ipv6]",
            "method=ignore",
            "",
        ]
    ),
    encoding="utf-8",
)

(network_dir / f"{bridge_name}-port-{bridge_parent}.nmconnection").write_text(
    "\n".join(
        [
            "[connection]",
            f"id={bridge_name}-port-{bridge_parent}",
            "type=ethernet",
            f"interface-name={bridge_parent}",
            f"master={bridge_name}",
            "slave-type=bridge",
            "autoconnect=true",
            "",
            "[ipv4]",
            "method=disabled",
            "",
            "[ipv6]",
            "method=ignore",
            "",
        ]
    ),
    encoding="utf-8",
)

(network_dir / "niurk-24-cluster-route.netplan.yaml").write_text(
    "\n".join(
        [
            "network:",
            "  version: 2",
            "  ethernets:",
            f"    {cluster_iface}:",
            "      dhcp4: false",
            f"      addresses: [{cluster_addr}]",
            "      routes:",
            f"        - to: {bridge_subnet}",
            f"          via: {cluster_gateway}",
            "          metric: 50",
            "",
        ]
    ),
    encoding="utf-8",
)

(network_dir / "niurk-42-port-map.json").write_text(
    json.dumps(
        {
            "generatedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "host": compute_host.get("host", "ark-rhiz"),
            "vm": compute_vm.get("vm", "niurk-42"),
            "address": compute_vm_addr,
            "ports": compute_vm.get("exposed_ports", []),
            "services": services,
        },
        indent=2,
    )
    + "\n",
    encoding="utf-8",
)

(ceph_dir / "ceph.client.niurk-24.conf").write_text(
    "\n".join(
        [
            "[global]",
            f"fsid = {ceph.get('cluster_name', 'ceph')}",
            f"mon_host = {', '.join(ceph_mon_hosts) if ceph_mon_hosts else 'CHANGE_ME_MON_HOSTS'}",
            f"public_network = {ceph.get('public_network', '10.42.0.0/24')}",
            f"cluster_network = {ceph.get('cluster_network', '10.42.0.0/24')}",
            f"client_mount_timeout = 30",
            "",
            f"[client.{(ceph.get('client_ids') or ['client.niurk-24'])[0]}]",
            "key = REPLACE_CEPH_SECRET",
            "",
        ]
    ),
    encoding="utf-8",
)

(ceph_dir / "cephfs-shared.mount").write_text(
    "\n".join(
        [
            "# Example CephFS mount for niurk-24",
            f"{(ceph_mon_hosts[0] if ceph_mon_hosts else 'CHANGE_ME_MON')}:/ /mnt/{ceph.get('filesystem_pool', 'cephfs-shared')} ceph name={(ceph.get('client_ids') or ['client.niurk-24'])[0]},secret=REPLACE_CEPH_SECRET,_netdev,noatime 0 0",
            "",
        ]
    ),
    encoding="utf-8",
)

summary = {
    "generatedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    "directiveId": cluster.get("id"),
    "paths": {
        "bridge": str(network_dir / f"{bridge_name}.nmconnection"),
        "bridgePort": str(network_dir / f"{bridge_name}-port-{bridge_parent}.nmconnection"),
        "clusterRoute": str(network_dir / "niurk-24-cluster-route.netplan.yaml"),
        "portMap": str(network_dir / "niurk-42-port-map.json"),
        "cephClient": str(ceph_dir / "ceph.client.niurk-24.conf"),
        "cephFsMount": str(ceph_dir / "cephfs-shared.mount"),
    },
    "topology": topology,
    "services": services,
}
(out_dir / "cluster-integration-render.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(out_dir / "cluster-integration-render.json")
PY
