#!/usr/bin/env bash
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"

load_env
require_root
need_cmd timeout
need_cmd ceph

CEPH=(ceph -n client.admin -k /etc/ceph/ceph.client.admin.keyring --mon-host 10.42.0.38:6789)

log "Adding hosts to cephadm orchestrator..."

add_host() {
  local host="$1"
  local ip="$2"
  local labels="${3:-}"

  if timeout --foreground 10s "${CEPH[@]}" orch host ls 2>/dev/null | awk '{print $1}' | grep -qx "$host"; then
    log "Already present: $host"
    return 0
  fi

  if [[ -n "$labels" ]]; then
    timeout --foreground 60s "${CEPH[@]}" orch host add "$host" "$ip" --labels "$labels" || {
      warn "Failed to add $host ($ip)"
      return 1
    }
  else
    timeout --foreground 60s "${CEPH[@]}" orch host add "$host" "$ip" || {
      warn "Failed to add $host ($ip)"
      return 1
    }
  fi
}

add_host rhiz-loes     10.42.0.38 _admin
add_host ark-rhiz      10.42.0.40 _admin
add_host exosystem     10.42.0.21 _admin
add_host eliosys-rhiz  10.42.0.27
add_host factau-rhiz   10.42.0.4
add_host sigmo-rhiz    10.42.0.34 _admin
add_host rhiz-woute    10.42.0.33 _admin
add_host rhiz-ueth     10.42.0.2  _admin

log "Host enrollment pass complete."
