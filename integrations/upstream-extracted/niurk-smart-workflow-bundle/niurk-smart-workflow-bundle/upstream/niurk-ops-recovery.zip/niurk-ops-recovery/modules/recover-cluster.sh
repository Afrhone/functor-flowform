#!/usr/bin/env bash
# Main recovery automation for rhiz-loes (safe-by-default, modular)
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"

load_env
require_root

# Defaults (can be overridden via env)
export RECOVERY_MASTER_HOST="${RECOVERY_MASTER_HOST:-rhiz-loes}"
export RECOVERY_FSID="${RECOVERY_FSID:-b7b96750-2307-11f1-b1f3-80e82cc9d3f8}"
export I_UNDERSTAND_DISK_WILL_BE_WIPED="${I_UNDERSTAND_DISK_WILL_BE_WIPED:-no}"

log "=== Cluster Recovery (master=${RECOVERY_MASTER_HOST} fsid=${RECOVERY_FSID}) ==="

# 1) Non-destructive preflight
"${REPO_ROOT}/modules/11-system-check.sh"
"${REPO_ROOT}/modules/12-network-check.sh"

# 2) (Optional) Push remote config by host (SSH/prereqs/WG/host-profile)
if is_yes "${RECOVERY_APPLY_REMOTE_CONFIG:-yes}"; then
  "${REPO_ROOT}/modules/13-remote-config-by-host.sh"
else
  log "Skipping remote config (RECOVERY_APPLY_REMOTE_CONFIG!=yes)"
fi

# 3) Verify we are targeting the right cluster
"${REPO_ROOT}/modules/14-ceph-fsid-verify.sh"

# 4) Bring Ceph control plane back / redeploy safely
"${REPO_ROOT}/modules/15-ceph-redeploy-safe.sh"

# 5) Restore hosts + storage orchestration
"${REPO_ROOT}/modules/16-ceph-hosts-and-storage-restore.sh"

# 6) Render+check cluster integration payload (optional)
if is_yes "${RECOVERY_RENDER_INTEGRATION_STATUS:-yes}"; then
  "${REPO_ROOT}/modules/64-cluster-integration-render.sh" || true
  "${REPO_ROOT}/modules/65-cluster-integration-check.sh" || true
fi

# 7) Forward remote-config callback payload (optional)
if is_yes "${RECOVERY_FORWARD_REMOTE_CONFIG:-no}"; then
  "${REPO_ROOT}/modules/73-gateway-remote-config.sh" forward || true
fi

log "=== Recovery complete. Suggested checks: ==="
log "  ceph -s"
log "  ceph orch ps"
log "  ceph osd tree"
log "  ceph health detail"
