#!/usr/bin/env bash
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"
load_env

mode="${1:-full}"
status_file="$(generated_dir)/cluster-integration/cluster-integration-status.json"

log "running discovery"
"${SCRIPT_DIR}/04-discover.sh"

log "rendering cluster integration artifacts"
"${SCRIPT_DIR}/64-cluster-integration-render.sh"

log "checking cluster integration state"
"${SCRIPT_DIR}/65-cluster-integration-check.sh"

if [[ "$mode" != "offline" ]]; then
  log "minting gateway token"
  "${SCRIPT_DIR}/72-gateway-token-generate.sh" niurk-24 || warn "token generation failed"
fi

log "rendering trusted handshake"
"${SCRIPT_DIR}/74-trusted-fido-handshake.sh" render

if [[ -f "$status_file" ]]; then
  log "storing remote-config callback payload"
  "${SCRIPT_DIR}/73-gateway-remote-config.sh" store "$status_file"
fi

if [[ "${POST_HANDSHAKE:-no}" =~ ^(yes|YES|true|TRUE|1)$ ]]; then
  log "posting trusted handshake"
  "${SCRIPT_DIR}/74-trusted-fido-handshake.sh" post || warn "handshake post failed"
fi

log "projecting cloud-compute bundle"
python3 /cloud-compute/build_bundle.py

log "printing status"
"${SCRIPT_DIR}/90-status.sh"
