#!/usr/bin/env bash
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"
load_env
need_cmd python3
have_py_yaml || die "Missing PyYAML. Install python3-pyyaml / python3-yaml."

render_json="$(generated_dir)/cluster-integration/cluster-integration-render.json"
[[ -f "$render_json" ]] || die "Missing rendered cluster bundle: $render_json. Run ./bin/exosys.sh cluster-render first."

python3 - "$render_json" "$(inventory_file)" "$(cluster_integration_file)" <<'PY'
import json
import sys
from pathlib import Path

import yaml


render_path = Path(sys.argv[1])
inventory_path = Path(sys.argv[2])
cluster_path = Path(sys.argv[3])

render = json.loads(render_path.read_text(encoding="utf-8"))
inventory = yaml.safe_load(inventory_path.read_text(encoding="utf-8")) or {}
cluster = (yaml.safe_load(cluster_path.read_text(encoding="utf-8")) or {}).get("cluster_integration") or {}

hosts = {host["name"]: host for host in inventory.get("hosts", [])}
ark = hosts.get("ark-rhiz", {})
sigmo = hosts.get("sigmo-rhiz", {})
topology = render.get("topology", {})
compute_host = topology.get("compute_host", {})
compute_vm = topology.get("compute_vm", {})
paths = render.get("paths", {})

bridge = compute_host.get("bridge_name", "br-rhiz")
parent = compute_host.get("bridge_parent", "eno1")
host_addr = compute_host.get("lan_addr", "192.168.0.40/24")
vm_addr = compute_vm.get("lan_addr", "192.168.0.142/24")
vm_ip = vm_addr.split("/")[0]
ports = compute_vm.get("exposed_ports", [])
wg_file = ark.get("wg_directive", "directives/wg-ceph-operator.ark-rhiz.yaml")
sigmo_ip = ((sigmo.get("ssh") or {}).get("host")) or "CHANGE_ME_SIGMO_LAN_IP"

def emit(line=""):
    print(line)

emit("# ark-rhiz Fedora host apply bundle")
emit("# run from a console or tmux session on ark-rhiz; moving the parent NIC into a bridge can drop SSH")
emit("")
emit("export BRIDGE_NAME='%s'" % bridge)
emit("export BRIDGE_PARENT='%s'" % parent)
emit("export BRIDGE_ADDR='%s'" % host_addr)
emit("export VM_ADDR='%s'" % vm_ip)
emit("export WG_DIRECTIVE='%s'" % wg_file)
emit("export SIGMO_RHIZ_IP='%s'" % sigmo_ip)
emit("")
emit("# 1. review rendered artifacts")
for key in ("bridge", "bridgePort", "portMap"):
    if key in paths:
        emit("sed -n '1,220p' %s" % paths[key])
emit("")
emit("# 2. apply bridge with nmcli")
emit("sudo systemctl is-active --quiet NetworkManager || sudo systemctl start NetworkManager")
emit("sudo nmcli connection show \"$BRIDGE_NAME\" >/dev/null 2>&1 && sudo nmcli connection delete \"$BRIDGE_NAME\" || true")
emit("sudo nmcli connection show \"${BRIDGE_NAME}-port-${BRIDGE_PARENT}\" >/dev/null 2>&1 && sudo nmcli connection delete \"${BRIDGE_NAME}-port-${BRIDGE_PARENT}\" || true")
emit("sudo nmcli connection add type bridge ifname \"$BRIDGE_NAME\" con-name \"$BRIDGE_NAME\" bridge.stp no ipv4.method manual ipv4.addresses \"$BRIDGE_ADDR\" ipv6.method ignore autoconnect yes")
emit("sudo nmcli connection add type ethernet ifname \"$BRIDGE_PARENT\" con-name \"${BRIDGE_NAME}-port-${BRIDGE_PARENT}\" master \"$BRIDGE_NAME\" slave-type bridge ipv4.method disabled ipv6.method ignore autoconnect yes")
emit("sudo nmcli connection up \"$BRIDGE_NAME\"")
emit("sudo nmcli connection up \"${BRIDGE_NAME}-port-${BRIDGE_PARENT}\"")
emit("")
emit("# 3. assign bridge and Ceph operator interfaces to a trusted firewalld zone")
emit("sudo firewall-cmd --permanent --zone trusted --add-interface \"$BRIDGE_NAME\"")
emit("sudo firewall-cmd --permanent --zone trusted --add-interface ceph-operator")
emit("")
emit("# 4. expose niurk-42 services on ark-rhiz itself")
for port in ports:
    emit(f"sudo firewall-cmd --permanent --zone trusted --add-port={port}/tcp")
emit("")
emit("# 5. optional host relay from ark-rhiz -> niurk-42 for clients that target the host IP")
for port in ports:
    emit(f"sudo firewall-cmd --permanent --zone trusted --add-forward-port=port={port}:proto=tcp:toaddr={vm_ip}:toport={port}")
emit("sudo firewall-cmd --reload")
emit("")
emit("# 6. review and apply WireGuard overlay after replacing placeholders")
emit("sed -n '1,220p' /ops/%s" % wg_file)
emit("sudo sed -i \"s/CHANGE_ME_SIGMO_LAN_IP/${SIGMO_RHIZ_IP}/\" /ops/%s" % wg_file)
emit("sudo WG_CEPH_DIRECTIVE_FILE=%s ./bin/exosys.sh wg-apply" % wg_file)
emit("")
emit("# 7. validate host state")
emit("nmcli connection show \"$BRIDGE_NAME\"")
emit("ip -brief address show \"$BRIDGE_NAME\"")
emit("sudo firewall-cmd --zone trusted --list-interfaces")
emit("sudo firewall-cmd --zone trusted --list-ports")
emit("sudo firewall-cmd --zone trusted --list-forward-ports")
emit("curl -fsS --connect-timeout 3 http://${VM_ADDR}:11434/api/tags")
emit("curl -fsS --connect-timeout 3 http://${VM_ADDR}:8013/health")
emit("")
emit("# 8. if you want ark-rhiz to consume the generated keyfiles instead of direct nmcli creation")
emit("sudo install -d -m 700 /etc/NetworkManager/system-connections")
emit("sudo install -m 600 %s /etc/NetworkManager/system-connections/%s.nmconnection" % (paths.get("bridge", ""), bridge))
emit("sudo install -m 600 %s /etc/NetworkManager/system-connections/%s-port-%s.nmconnection" % (paths.get("bridgePort", ""), bridge, parent))
emit("sudo nmcli connection reload")
emit("sudo nmcli connection up \"$BRIDGE_NAME\"")
emit("sudo nmcli connection up \"${BRIDGE_NAME}-port-${BRIDGE_PARENT}\"")
PY
