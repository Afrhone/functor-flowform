#!/usr/bin/env bash
# Validate Ceph public/cluster network presence (non-destructive)
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"

load_env
require_root

need_cmd ip
need_cmd python3

MASTER_HOST="${RECOVERY_MASTER_HOST:-rhiz-loes}"
[[ "$(hostname -s)" == "${MASTER_HOST}" ]] || die "Run on ${MASTER_HOST} (or set RECOVERY_MASTER_HOST)."

MON_IP="${CEPH_BOOTSTRAP_MON_IP:?CEPH_BOOTSTRAP_MON_IP not set in .env}"
PUB_CIDR="${CEPH_PUBLIC_NETWORK:?CEPH_PUBLIC_NETWORK not set in .env}"
CLUSTER_CIDR="${CEPH_CLUSTER_NETWORK:?CEPH_CLUSTER_NETWORK not set in .env}"

log "Network check: mon_ip=${MON_IP} public=${PUB_CIDR} cluster=${CLUSTER_CIDR}"

if ! ip -4 addr show | grep -q " ${MON_IP}/"; then
  die "Missing mon IP ${MON_IP} on $(hostname -s). Fix NetworkManager before proceeding."
fi

# Basic route sanity: ensure we have a route for the public network
if ! ip route show | grep -q "${PUB_CIDR%/*}"; then
  warn "No route line matched '${PUB_CIDR%/*}'. This may be OK (depends on routing)."
fi

log "Listing interfaces with 10/172/192 ranges (quick human scan)"
ip -4 -o addr show | awk '{print $2, $4}' | sed 's/\/[0-9]\+//'

log "Network check complete."
