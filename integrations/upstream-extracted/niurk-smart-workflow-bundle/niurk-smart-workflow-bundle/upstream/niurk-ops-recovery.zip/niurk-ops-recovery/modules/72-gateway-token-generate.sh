#!/usr/bin/env bash
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"
load_env
name="${1:-node}"
out="$(generated_dir)/tokens/${name}-$(date +%Y%m%d%H%M%S).json"
mkdir -p "$(dirname "$out")"
python3 - "$out" "$name" "${ENROLLMENT_TOKEN_TTL_HOURS:-24}" "$(inventory_file)" "$(gateway_file)" "${REMOTE_CONFIG_CALLBACK:-}" "$(cluster_integration_file)" "${ENROLLMENT_DEFAULT_SCOPES:-remote-config:read,handshake:init,gateway:models:read,mcp:invoke}" <<'PY'
import json, secrets, sys, time
try:
    import yaml
except Exception as e:
    raise SystemExit("Missing PyYAML. Install python3-pyyaml / python3-yaml") from e

out, name, ttl, inventory_path, gateway_path, callback, cluster_path, scopes = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4], sys.argv[5], sys.argv[6], sys.argv[7], sys.argv[8]
now = int(time.time())
with open(inventory_path, 'r', encoding='utf-8') as f:
    inventory = yaml.safe_load(f) or {}
with open(gateway_path, 'r', encoding='utf-8') as f:
    gateway = (yaml.safe_load(f) or {}).get('gateway', {})
with open(cluster_path, 'r', encoding='utf-8') as f:
    cluster = (yaml.safe_load(f) or {}).get('cluster_integration', {})
host_meta = next((h for h in inventory.get('hosts', []) if h.get('name') == name), None)
obj = {
    'name': name,
    'token': secrets.token_urlsafe(32),
    'issued_at': now,
    'expires_at': now + ttl * 3600,
    'scopes': [item.strip() for item in scopes.split(',') if item.strip()],
}
if gateway or callback:
    obj['gateway'] = {
        'host': gateway.get('host', ''),
        'public_endpoint': gateway.get('public_endpoint', ''),
        'remote_config_callback': callback,
    }
if cluster:
    obj['cluster_integration'] = {
        'id': cluster.get('id', ''),
        'objective': cluster.get('objective', ''),
        'llama_gpu_url': ((cluster.get('services') or {}).get('llama_gpu') or {}).get('relay', ''),
        'backend_bi_url': ((cluster.get('services') or {}).get('backend_bi') or {}).get('relay', ''),
        'trusted_handshake_mode': ((cluster.get('trust') or {}).get('mode', '')),
    }
if host_meta:
    ssh = host_meta.get('ssh') or {}
    obj['host_profile'] = {
        'profile': host_meta.get('profile', ''),
        'os': host_meta.get('os', ''),
        'roles': host_meta.get('roles') or [],
        'ceph_addr': host_meta.get('ceph_addr', ''),
        'wg_directive': host_meta.get('wg_directive', ''),
        'ssh': {
            'user': ssh.get('user', ''),
            'host': ssh.get('host', ''),
            'port': ssh.get('port', 22),
        },
        'libvirt': host_meta.get('libvirt') or {},
    }
    obj['automation'] = {
        'local_net_target': ssh.get('host', ''),
        'gateway_endpoint': gateway.get('public_endpoint', ''),
        'remote_config_callback': callback,
        'workflow': 'cloud-compute',
    }
open(out, 'w', encoding='utf-8').write(json.dumps(obj, indent=2))
latest = out.rsplit('-', 1)[0] + '-latest.json'
open(latest, 'w', encoding='utf-8').write(json.dumps(obj, indent=2))
print(out)
PY
