#!/usr/bin/env bash
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"
load_env
need_cmd python3
have_py_yaml || die "Missing PyYAML. Install python3-pyyaml / python3-yaml."

out_dir="$(generated_dir)/cluster-integration"
mkdir -p "$out_dir"

python3 - "$(cluster_integration_file)" "$out_dir/cluster-integration-status.json" "$(generated_dir)/discovery.json" <<'PY'
import json
import shutil
import socket
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml


def run(command):
    try:
        output = subprocess.check_output(command, text=True, stderr=subprocess.STDOUT).strip()
        return {"ok": True, "detail": output}
    except Exception as exc:
        detail = getattr(exc, "output", "") or str(exc)
        return {"ok": False, "detail": detail.strip()}


def route_probe(ip_addr):
    return run(["ip", "route", "get", ip_addr]) if shutil.which("ip") else {"ok": False, "detail": "ip command missing"}


def http_probe(url):
    if not shutil.which("curl"):
        return {"ok": False, "detail": "curl missing"}
    return run(["curl", "-fsS", "--connect-timeout", "3", url])


directive_path = Path(sys.argv[1])
out_path = Path(sys.argv[2])
discovery_path = Path(sys.argv[3])
with directive_path.open("r", encoding="utf-8") as handle:
    cluster = (yaml.safe_load(handle) or {}).get("cluster_integration") or {}

topology = cluster.get("topology") or {}
services = cluster.get("services") or {}
trust = cluster.get("trust") or {}
ceph = cluster.get("ceph") or {}
app_vm = topology.get("applicative_vm") or {}
compute_vm = topology.get("compute_vm") or {}
hypergraph_vm = topology.get("hypergraph_vm") or {}

compute_ip = str(compute_vm.get("lan_addr", "192.168.0.142/24")).split("/")[0]
hypergraph_ip = str(hypergraph_vm.get("lan_addr", "192.168.0.33")).split("/")[0]
gateway_url = trust.get("handshake", "https://rhiz-arch.afrho.net/api/handshake")

discovery = {}
if discovery_path.exists():
    try:
        discovery = json.loads(discovery_path.read_text(encoding="utf-8"))
    except Exception:
        discovery = {"error": "unreadable"}

status = {
    "generatedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    "directiveId": cluster.get("id"),
    "host": socket.gethostname().split(".")[0],
    "commands": {name: bool(shutil.which(name)) for name in ["docker", "lxc", "ceph", "wg", "nmcli", "virsh", "ssh-keygen", "curl"]},
    "discovery": discovery,
    "interfaces": run(["bash", "-lc", "ip -brief address 2>/dev/null || true"]),
    "routeChecks": {
        "arkRhiz": route_probe(str((topology.get("compute_host") or {}).get("lan_addr", "192.168.0.40/24")).split("/")[0]),
        "niurk42": route_probe(compute_ip),
        "niurk43": route_probe(hypergraph_ip),
    },
    "dns": {
        "niurk-42": run(["getent", "hosts", "niurk-42"]) if shutil.which("getent") else {"ok": False, "detail": "getent missing"},
        "niurk-43": run(["getent", "hosts", "niurk-43"]) if shutil.which("getent") else {"ok": False, "detail": "getent missing"},
    },
    "reachability": {
        "llamaGpu": http_probe(f"http://{compute_ip}:11434{services.get('llama_gpu', {}).get('health', '/api/tags')}"),
        "backendBi": http_probe(f"http://{compute_ip}:8013{services.get('backend_bi', {}).get('health', '/health')}"),
        "hypergraph": http_probe(gateway_url.replace("/api/handshake", "/api/gateway/hypergraph/health")),
        "handshake": http_probe(gateway_url),
    },
    "cluster": {
        "lxcCluster": run(["bash", "-lc", "lxc cluster list 2>&1 || true"]) if shutil.which("lxc") else {"ok": False, "detail": "lxc missing"},
        "dockerSwarm": run(["bash", "-lc", "docker info --format '{{.Swarm.LocalNodeState}}' 2>&1 || true"]) if shutil.which("docker") else {"ok": False, "detail": "docker missing"},
        "dockerServices": run(["bash", "-lc", "docker service ls 2>&1 || true"]) if shutil.which("docker") else {"ok": False, "detail": "docker missing"},
        "wireguard": run(["bash", "-lc", "wg show 2>&1 || true"]) if shutil.which("wg") else {"ok": False, "detail": "wg missing"},
    },
    "ceph": {
        "configured": Path("/etc/ceph/ceph.conf").exists(),
        "status": run(["bash", "-lc", "ceph -s 2>&1 || true"]) if shutil.which("ceph") else {"ok": False, "detail": "ceph missing"},
        "clientIds": ceph.get("client_ids", []),
    },
    "expected": {
        "applicativeVm": app_vm.get("vm"),
        "computeVm": compute_vm.get("vm"),
        "hypergraphVm": hypergraph_vm.get("vm"),
    },
}

out_path.write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8")
print(out_path)
PY
