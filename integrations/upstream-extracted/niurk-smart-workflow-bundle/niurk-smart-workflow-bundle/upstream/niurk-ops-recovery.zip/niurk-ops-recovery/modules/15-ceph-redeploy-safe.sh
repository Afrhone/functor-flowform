#!/usr/bin/env bash
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"

load_env
require_root

need_cmd cephadm
need_cmd systemctl
need_cmd ip
need_cmd timeout
need_cmd jq

MASTER_HOST="${RECOVERY_MASTER_HOST:-rhiz-loes}"
[[ "$(hostname -s)" == "${MASTER_HOST}" ]] || die "Run on ${MASTER_HOST} (or set RECOVERY_MASTER_HOST)."

TARGET_FSID="${RECOVERY_FSID:-b7b96750-2307-11f1-b1f3-80e82cc9d3f8}"
MON_IP="${CEPH_BOOTSTRAP_MON_IP:?CEPH_BOOTSTRAP_MON_IP not set in .env}"

log "Ceph safe redeploy: fsid=${TARGET_FSID} mon_ip=${MON_IP}"

ip -4 addr show | grep -q " ${MON_IP}/" || die "Missing mon IP ${MON_IP} on this host"

if systemctl list-unit-files 2>/dev/null | grep -q '^cephadm\.service'; then
  log "Restarting cephadm.service"
  timeout --foreground 5s systemctl restart cephadm.service || true
else
  warn "cephadm.service not present on this host; skipping cephadm service restart."
fi

log "Starting local Ceph instance units for target FSID (best-effort)"
mapfile -t units < <(
  systemctl list-unit-files --type=service --no-legend 2>/dev/null \
  | awk '{print $1}' \
  | grep "^ceph-${TARGET_FSID}@[^.].*\.service$" \
  | grep -v "^ceph-${TARGET_FSID}@\.service$" || true
)

for u in "${units[@]}"; do
  [[ -n "$u" ]] || continue
  log "Starting $u"
  systemctl enable "$u" >/dev/null 2>&1 || true
  timeout --foreground 8s systemctl start "$u" || true
done

log "Local daemon inventory (non-blocking)"
cephadm_json="$(timeout --foreground 10s cephadm ls 2>/dev/null || true)"
if [[ -n "$cephadm_json" ]]; then
  printf '%s\n' "$cephadm_json"
fi

live_fsid="$(printf '%s\n' "$cephadm_json" | jq -r 'map(select(.fsid != null))[0].fsid // empty' 2>/dev/null || true)"
if [[ "$live_fsid" == "$TARGET_FSID" ]]; then
  log "Live FSID confirmed from cephadm ls: ${live_fsid}"
  exit 0
fi

cli_fsid="$(timeout --foreground 8s ceph fsid 2>/dev/null || true)"
if [[ "$cli_fsid" == "$TARGET_FSID" ]]; then
  log "Live FSID confirmed from ceph fsid: ${cli_fsid}"
  exit 0
fi

die "Could not confirm live FSID ${TARGET_FSID}. cephadm ls returned '${live_fsid:-<empty>}' and ceph fsid returned '${cli_fsid:-<empty>}'."
