#!/usr/bin/env bash
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"
load_env

EXPECTED_FSID="${CLUSTER_FSID:-b7b96750-2307-11f1-b1f3-80e82cc9d3f8}"
log "Verifying Ceph FSID=${EXPECTED_FSID}"

actual_fsid="$(timeout --foreground 10s cephadm ls 2>/dev/null | jq -r 'map(select(.fsid != null))[0].fsid' 2>/dev/null || true)"
if [[ -z "${actual_fsid}" || "${actual_fsid}" == "null" ]]; then
  actual_fsid="$(timeout --foreground 10s ceph fsid 2>/dev/null || true)"
fi

[[ -n "${actual_fsid}" ]] || die "Could not determine FSID (timed out or no local ceph response)"
[[ "${actual_fsid}" == "${EXPECTED_FSID}" ]] || die "FSID mismatch: got ${actual_fsid}, expected ${EXPECTED_FSID}"

log "FSID verified: ${actual_fsid}"
