#!/usr/bin/env bash
# Host recovery automation (safe-by-default)
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"

load_env
require_root

export RECOVERY_MASTER_HOST="${RECOVERY_MASTER_HOST:-rhiz-loes}"
export RECOVERY_FSID="${RECOVERY_FSID:-b7b96750-2307-11f1-b1f3-80e82cc9d3f8}"
export I_UNDERSTAND_DISK_WILL_BE_WIPED="${I_UNDERSTAND_DISK_WILL_BE_WIPED:-no}"

log "=== Host Recovery (master=${RECOVERY_MASTER_HOST} fsid=${RECOVERY_FSID}) ==="

"${REPO_ROOT}/modules/11-system-check.sh"
"${REPO_ROOT}/modules/12-network-check.sh"
"${REPO_ROOT}/modules/13-remote-config-by-host.sh"

log "Host recovery complete. (Next: run modules/recover-cluster.sh to restore Ceph control plane + storage.)"
