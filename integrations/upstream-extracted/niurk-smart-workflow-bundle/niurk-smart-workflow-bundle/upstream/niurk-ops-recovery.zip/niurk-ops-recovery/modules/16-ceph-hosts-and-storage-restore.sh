#!/usr/bin/env bash
# Restore hosts + OSD/storage orchestration (non-destructive, fail-fast, cephadm-aware)
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"

load_env
require_root

need_cmd cephadm
need_cmd python3
need_cmd timeout
need_cmd jq

MASTER_HOST="${RECOVERY_MASTER_HOST:-rhiz-loes}"
[[ "$(hostname -s)" == "${MASTER_HOST}" ]] || die "Run on ${MASTER_HOST} (or set RECOVERY_MASTER_HOST)."

TARGET_FSID="${RECOVERY_FSID:-b7b96750-2307-11f1-b1f3-80e82cc9d3f8}"

log "Restoring Ceph hosts + storage for FSID=${TARGET_FSID}"

cephadm_json="$(timeout --foreground 10s cephadm ls 2>/dev/null || true)"
live_fsid="$(printf '%s\n' "$cephadm_json" | jq -r 'map(select(.fsid != null))[0].fsid // empty' 2>/dev/null || true)"

if [[ "$live_fsid" != "$TARGET_FSID" ]]; then
  cli_fsid="$(timeout --foreground 8s ceph fsid 2>/dev/null || true)"
  [[ "$cli_fsid" == "$TARGET_FSID" ]] || die "No live FSID confirmation for ${TARGET_FSID}. cephadm ls='${live_fsid:-<empty>}' ceph fsid='${cli_fsid:-<empty>}'"
fi

export I_UNDERSTAND_DISK_WILL_BE_WIPED="${I_UNDERSTAND_DISK_WILL_BE_WIPED:-no}"

log "Step 1: Skipping host prepare (already bootstrapped manually/by-host)."

log "Step 2: Enroll hosts into Ceph orchestrator"
timeout --foreground 60s "${REPO_ROOT}/modules/31-ceph-host-bulk-add.sh" || true

log "Step 3: Place core daemons (mon/mgr/osd defaults)"
timeout --foreground 60s "${REPO_ROOT}/modules/35-ceph-core-place.sh" || true

log "Step 4: Refresh device inventory"
timeout --foreground 30s ceph orch device ls --refresh || true

log "Step 5: Apply OSD spec (no zapping)"
timeout --foreground 60s "${REPO_ROOT}/modules/32a-ceph-osd-spec-apply.sh" || true

log "Step 6: Ensure pool + client auth (idempotent)"
timeout --foreground 30s "${REPO_ROOT}/modules/33a-ceph-pool-create.sh" || true
timeout --foreground 30s "${REPO_ROOT}/modules/33-ceph-pool-auth.sh" || true

log "Hosts + storage restore complete."
