#!/usr/bin/env bash
# Non-destructive system readiness checks (does NOT erase config/data)
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"

load_env
require_root

need_cmd hostname
need_cmd ip
need_cmd ss
need_cmd python3

MASTER_HOST="${RECOVERY_MASTER_HOST:-rhiz-loes}"
TARGET_FSID="${RECOVERY_FSID:-b7b96750-2307-11f1-b1f3-80e82cc9d3f8}"

log "System check: host=$(hostname -s) expected_master=${MASTER_HOST} target_fsid=${TARGET_FSID}"

if [[ "$(hostname -s)" != "${MASTER_HOST}" ]]; then
  die "Run recovery automation on ${MASTER_HOST} (set RECOVERY_MASTER_HOST if different)."
fi

# Safety guard: default to non-destructive behavior.
# (Many Ceph workflows use this env var as an explicit zap/wipe gate.)
if [[ "${I_UNDERSTAND_DISK_WILL_BE_WIPED:-no}" != "no" ]]; then
  warn "I_UNDERSTAND_DISK_WILL_BE_WIPED is set to '${I_UNDERSTAND_DISK_WILL_BE_WIPED}'."
  warn "For recovery, set it to 'no' unless you are intentionally zapping disks."
fi

log "Checking time sync services (chronyd/systemd-timesyncd) ..."
if systemctl is-active chronyd >/dev/null 2>&1; then
  log "chronyd: active"
elif systemctl is-active systemd-timesyncd >/dev/null 2>&1; then
  log "systemd-timesyncd: active"
else
  warn "No time sync service detected (recommended for Ceph quorum)."
fi

log "Checking firewall service ..."
if systemctl is-active firewalld >/dev/null 2>&1; then
  log "firewalld: active"
else
  warn "firewalld not active (ensure required Ceph ports are reachable)."
fi

log "Checking SSH reachability for inventory hosts (non-fatal) ..."
INV="$(inventory_file)"
mapfile -t hosts < <(python3 - "$INV" <<'PY'
import sys, yaml
with open(sys.argv[1],'r',encoding='utf-8') as f:
  d=yaml.safe_load(f) or {}
for h in d.get('hosts',[]):
  name=h.get('name')
  if name: print(name)
PY
)

for h in "${hosts[@]}"; do
  if [[ "$h" == "$(hostname -s)" ]]; then continue; fi
  if ssh -o BatchMode=yes -o ConnectTimeout=4 "${h}" 'echo ok' >/dev/null 2>&1; then
    log "ssh ok: ${h}"
  else
    warn "ssh not ready: ${h} (will retry during bootstrap)"
  fi
done

log "System check complete (non-destructive)."
