#!/usr/bin/env bash
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"
load_env

echo "== Host =="
hostnamectl --static 2>/dev/null || hostname -s || true

echo
printf '== WireGuard ==\n'
if command -v wg >/dev/null 2>&1; then
  wg show "${WG_CEPH_IF:-ceph-operator}" 2>/dev/null || true
fi

echo
printf '== Ceph ==\n'
if command -v ceph >/dev/null 2>&1; then
  sudo ceph -s 2>/dev/null || true
fi

echo
printf '== libvirt ==\n'
if command -v virsh >/dev/null 2>&1; then
  virsh pool-list --all 2>/dev/null || true
  virsh list --all 2>/dev/null || true
fi

echo
printf '== LXD / Docker ==\n'
command -v lxd >/dev/null 2>&1 && lxd --version || true
command -v docker >/dev/null 2>&1 && docker --version || true
command -v docker >/dev/null 2>&1 && docker info --format '{{.Swarm.LocalNodeState}}' 2>/dev/null || true

echo
printf '== Generated SSH config ==\n'
ls -l "$(generated_dir)/ssh_config" 2>/dev/null || true

echo
printf '== Cluster integration ==\n'
if [[ -f "$(generated_dir)/cluster-integration/cluster-integration-status.json" ]]; then
  python3 - "$(generated_dir)/cluster-integration/cluster-integration-status.json" <<'PY'
import json
import sys
from pathlib import Path

data = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
print(f"host={data.get('host','')}")
for name, result in (data.get("routeChecks") or {}).items():
    print(f"route[{name}]={'ok' if result.get('ok') else 'fail'} {result.get('detail','')}")
for name, result in (data.get("reachability") or {}).items():
    print(f"probe[{name}]={'ok' if result.get('ok') else 'fail'}")
print(f"ceph.configured={data.get('ceph',{}).get('configured')}")
PY
else
  echo "no cluster integration status generated"
fi

echo
printf '== Trusted handshake ==\n'
if [[ -f "$(generated_dir)/cluster-integration/trusted-handshake.json" ]]; then
  python3 - "$(generated_dir)/cluster-integration/trusted-handshake.json" "$(generated_dir)/cluster-integration/trusted-handshake.signed.json" <<'PY'
import json
import sys
from pathlib import Path

payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
signed = Path(sys.argv[2]).exists()
handshake = payload.get("handshake", {})
print(f"mode={handshake.get('mode','')}")
print(f"endpoint={handshake.get('endpoint','')}")
print(f"signed={signed}")
print(f"callback={handshake.get('callback','')}")
PY
else
  echo "no trusted handshake payload generated"
fi
