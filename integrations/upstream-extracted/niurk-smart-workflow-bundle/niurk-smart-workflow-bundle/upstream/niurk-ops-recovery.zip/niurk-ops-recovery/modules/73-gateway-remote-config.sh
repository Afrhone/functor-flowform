#!/usr/bin/env bash
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"
load_env

action="${1:-forward}"
json_file=""
callback_url="${REMOTE_CONFIG_CALLBACK:-}"

case "$action" in
  store|show|forward)
    shift || true
    ;;
  *)
    json_file="$action"
    action="forward"
    shift || true
    ;;
esac

[[ -n "$json_file" ]] || json_file="${1:-$(generated_dir)/cluster-integration/cluster-integration-status.json}"
[[ -n "${2:-}" ]] && callback_url="$2"

callback_dir="$(generated_dir)/remote-config-callback"
mkdir -p "$callback_dir"
latest_payload="${callback_dir}/latest.json"

store_payload() {
  local source_file="$1"
  [[ -f "$source_file" ]] || die "JSON file not found: $source_file"
  cp "$source_file" "$latest_payload"
  printf '%s\n' "$latest_payload"
}

forward_payload() {
  local source_file="$1"
  [[ -n "$callback_url" ]] || die "REMOTE_CONFIG_CALLBACK is required for forward"
  need_cmd curl
  local stored
  stored="$(store_payload "$source_file")"
  curl_args=(
    -fsS
    -X POST
    -H 'Content-Type: application/json'
    --data-binary @"$stored"
  )
  if [[ -n "${REMOTE_CONFIG_CALLBACK_AUTH_HEADER:-}" && -n "${REMOTE_CONFIG_CALLBACK_TOKEN:-}" ]]; then
    curl_args+=(-H "${REMOTE_CONFIG_CALLBACK_AUTH_HEADER}: ${REMOTE_CONFIG_CALLBACK_TOKEN}")
  fi
  if [[ -n "${REMOTE_CONFIG_CALLBACK_BEARER_TOKEN:-}" ]]; then
    curl_args+=(-H "Authorization: Bearer ${REMOTE_CONFIG_CALLBACK_BEARER_TOKEN}")
  fi
  curl "${curl_args[@]}" "${callback_url}"
}

case "$action" in
  store)
    store_payload "$json_file"
    ;;
  show)
    [[ -f "$latest_payload" ]] || die "No stored callback payload at $latest_payload"
    cat "$latest_payload"
    ;;
  forward)
    forward_payload "$json_file"
    ;;
  *)
    die "Usage: $(basename "$0") [store|show|forward] [json-file] [callback-url]"
    ;;
esac
