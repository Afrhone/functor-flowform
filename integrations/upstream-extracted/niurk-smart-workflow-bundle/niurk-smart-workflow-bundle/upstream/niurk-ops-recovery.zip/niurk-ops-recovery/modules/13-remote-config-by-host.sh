#!/usr/bin/env bash
# Push bundle to each host and apply host-specific non-destructive remote config
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"

load_env
require_root
need_cmd ssh
need_cmd rsync
need_cmd python3

MASTER_HOST="${RECOVERY_MASTER_HOST:-rhiz-loes}"
[[ "$(hostname -s)" == "${MASTER_HOST}" ]] || die "Run on ${MASTER_HOST} (or set RECOVERY_MASTER_HOST)."

INV="$(inventory_file)"
ssh_cfg="$(generated_dir)/ssh_config"
[[ -f "$ssh_cfg" ]] || "${REPO_ROOT}/modules/24-ssh-config-render.sh" "$ssh_cfg"

remote_dir="${REMOTE_BUNDLE_DIR:-~/$(basename "$REPO_ROOT")}"
remote_dir="${remote_dir// /}"

mapfile -t hosts < <(python3 - "$INV" <<'PY'
import sys, yaml
with open(sys.argv[1], 'r', encoding='utf-8') as f:
    d = yaml.safe_load(f) or {}
for h in d.get('hosts', []):
    name = h.get('name')
    if name:
        print(name)
PY
)

for h in "${hosts[@]}"; do
  if [[ "$h" == "$(hostname -s)" ]]; then
    log "Skipping self ($h) for remote bootstrap."
    continue
  fi

  host_remote_dir="$remote_dir"
  if [[ "$h" == "exosystem" ]]; then
    host_remote_dir="/home/kobaltafrhophiloes/niurk-ops-recovery"
  elif [[ "$h" == "eliosys-rhiz" ]]; then
    host_remote_dir="/home/kobalts71-n--1/niurk-ops-recovery"
  fi

  log "=== Remote bootstrap: $h ==="

  rsync -az --delete -e "ssh -F ${ssh_cfg}" \
    --exclude '.git' --exclude '.env' --exclude 'generated' --exclude '.cache' \
    "${REPO_ROOT}/" "${h}:${host_remote_dir}/"

  wg_yaml="directives/wg-ceph-operator.${h}.yaml"
  if ! ssh -F "$ssh_cfg" "$h" "test -f ${host_remote_dir}/${wg_yaml}" >/dev/null 2>&1; then
    wg_yaml="${WG_CEPH_DIRECTIVE_FILE:-directives/wg-ceph-operator.yaml}"
  fi

  if [[ "$h" == "eliosys-rhiz" ]]; then
    ssh -F "$ssh_cfg" "$h" bash -s -- "$host_remote_dir" "$wg_yaml" "$h" "${WG_CEPH_IF}" "${WG_CEPH_PRIVATE_KEY_FILE}" <<'REMOTE'
set -euo pipefail
host_remote_dir="$1"
wg_yaml="$2"
host_name="$3"
wg_if="$4"
wg_key_file="$5"

cd "$host_remote_dir"
cp -n env.example .env >/dev/null 2>&1 || true

sudo rm -f /etc/apt/sources.list.d/ceph.list /etc/apt/sources.list.d/ceph.list.save
sudo find /etc/apt/sources.list.d -maxdepth 1 -type f \( -name '*ceph*' -o -name '*squid*' \) -delete || true
sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y \
  python3 python3-yaml jq curl git rsync openssh-client wireguard-tools \
  podman qemu-system libvirt-daemon-system virtinst cloud-image-utils qemu-utils lvm2

sudo mkdir -p /etc/wireguard

sudo python3 - "$host_remote_dir/$wg_yaml" "$wg_if" "$wg_key_file" > "/tmp/${wg_if}.conf" <<'PY'
import sys, ipaddress
import yaml

yaml_path, ifname, privkey_file = sys.argv[1:4]
with open(yaml_path, 'r', encoding='utf-8') as f:
    cfg = yaml.safe_load(f) or {}

iface = cfg.get("interface", {}) or {}
peers = cfg.get("peers", []) or []

address = str(iface.get("address", "")).strip()
listen_port = int(iface.get("listen_port", 51820))
mtu = int(iface.get("mtu", 1420))
if not address:
    raise SystemExit("interface.address missing in directives file")

with open(privkey_file, "r", encoding="utf-8") as f:
    private_key = f.read().strip()
if not private_key:
    raise SystemExit("private key file is empty")

lines = [
    "[Interface]",
    f"Address = {address}",
    f"ListenPort = {listen_port}",
    f"MTU = {mtu}",
    f"PrivateKey = {private_key}",
    ""
]

iface_ip = str(ipaddress.ip_interface(address).ip)

for p in peers:
    name = (p.get("name") or "peer").strip()
    pub = (p.get("public_key") or "").strip()
    endpoint = (p.get("endpoint") or "").strip()
    allowed = p.get("allowed_ips") or ""
    keepalive = p.get("persistent_keepalive", 25)

    if isinstance(allowed, list):
        allowed_s = ", ".join(str(x).strip() for x in allowed if str(x).strip())
    else:
        allowed_s = str(allowed).strip()

    if not pub or pub.startswith("REPLACE_") or not allowed_s:
        continue

    peer_ips = []
    for item in [x.strip() for x in allowed_s.split(",") if x.strip()]:
        try:
            peer_ips.append(str(ipaddress.ip_network(item, strict=False).network_address))
        except Exception:
            pass
    if iface_ip in peer_ips:
        continue

    lines += [
        "[Peer]",
        f"# {name}",
        f"PublicKey = {pub}",
        f"AllowedIPs = {allowed_s}",
    ]
    if endpoint and "REPLACE" not in endpoint:
        lines.append(f"Endpoint = {endpoint}")
    if keepalive:
        lines.append(f"PersistentKeepalive = {int(keepalive)}")
    lines.append("")

sys.stdout.write("\n".join(lines).strip() + "\n")
PY

sudo install -m 600 -o root -g root "/tmp/${wg_if}.conf" "/etc/wireguard/${wg_if}.conf"
rm -f "/tmp/${wg_if}.conf"

sudo systemctl enable "wg-quick@${wg_if}" >/dev/null 2>&1 || true
sudo systemctl stop "wg-quick@${wg_if}" >/dev/null 2>&1 || true
sudo ip link show "${wg_if}" >/dev/null 2>&1 && sudo ip link delete "${wg_if}" || true
sudo systemctl start "wg-quick@${wg_if}"

sudo ./bin/exosys.sh host-profile-apply "$host_name"
REMOTE
  else
    ssh -F "$ssh_cfg" "$h" "set -euo pipefail; cd ${host_remote_dir}; \
      cp -n env.example .env >/dev/null 2>&1 || true; \
      sudo ./bin/exosys.sh prereqs; \
      if [ -f /etc/NetworkManager/system-connections/${WG_CEPH_IF}.nmconnection ]; then \
        sudo cp -a /etc/NetworkManager/system-connections/${WG_CEPH_IF}.nmconnection /etc/NetworkManager/system-connections/${WG_CEPH_IF}.nmconnection.bak.\$(date +%s) || true; \
      fi; \
      sudo WG_CEPH_DIRECTIVE_FILE=${wg_yaml} ./bin/exosys.sh wg-apply; \
      sudo ./bin/exosys.sh host-profile-apply ${h}"
  fi
done

log "Remote config applied (by host)."
