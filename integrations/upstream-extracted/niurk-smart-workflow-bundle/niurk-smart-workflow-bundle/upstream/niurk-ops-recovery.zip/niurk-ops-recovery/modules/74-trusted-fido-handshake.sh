#!/usr/bin/env bash
set -euo pipefail
source "$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/00-lib.sh"
load_env
need_cmd python3
have_py_yaml || die "Missing PyYAML. Install python3-pyyaml / python3-yaml."

action="${1:-render}"
out_dir="$(generated_dir)/cluster-integration"
mkdir -p "$out_dir"
payload_file="${out_dir}/trusted-handshake.json"
signed_file="${out_dir}/trusted-handshake.signed.json"
response_file="${out_dir}/trusted-handshake.response.json"

latest_token=""
if compgen -G "$(generated_dir)/tokens/*.json" >/dev/null 2>&1; then
  latest_token="$(ls -1t "$(generated_dir)"/tokens/*.json | head -n 1)"
fi

render_payload() {
  python3 - "$(cluster_integration_file)" "$payload_file" "${latest_token:-}" "$(current_host_guess)" <<'PY'
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml


directive_path = Path(sys.argv[1])
payload_path = Path(sys.argv[2])
token_path = Path(sys.argv[3]) if sys.argv[3] else None
current_host = sys.argv[4]

with directive_path.open("r", encoding="utf-8") as handle:
    cluster = (yaml.safe_load(handle) or {}).get("cluster_integration") or {}

token = {}
if token_path and token_path.exists():
    try:
        token = json.loads(token_path.read_text(encoding="utf-8"))
    except Exception:
        token = {}

topology = cluster.get("topology") or {}
services = cluster.get("services") or {}
trust = cluster.get("trust") or {}
payload = {
    "generatedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    "clusterId": cluster.get("id"),
    "handshake": {
        "rendered": True,
        "mode": trust.get("mode", "fido2+ed25519"),
        "rpId": trust.get("rp_id", "rhiz-arch.afrho.net"),
        "endpoint": trust.get("handshake", "https://rhiz-arch.afrho.net/api/handshake"),
        "callback": trust.get("callback", "https://rhiz-arch.afrho.net/api/enroll"),
        "node": {
            "host": current_host,
            "vm": (topology.get("applicative_vm") or {}).get("vm", "niurk-24"),
            "role": "applicative-edge",
            "clusterAddress": (topology.get("applicative_vm") or {}).get("cluster_addr", ""),
        },
        "services": services,
        "trustedPeers": [
            (topology.get("compute_host") or {}).get("host", "ark-rhiz"),
            (topology.get("compute_vm") or {}).get("vm", "niurk-42"),
            (topology.get("hypergraph_vm") or {}).get("vm", "niurk-43"),
            topology.get("swarm_manager", "factau-rhiz"),
        ],
        "capabilities": trust.get("capabilities", []),
        "scopes": trust.get("scopes", []),
        "token": {
            "file": str(token_path) if token_path else "",
            "name": token.get("name", ""),
            "expiresAt": token.get("expires_at", ""),
        },
        "signature": {
            "status": "pending-fido-signature",
            "keyPath": "",
        },
    },
}
payload_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
print(payload_path)
PY
}

sign_payload() {
  local key_path="${FIDO_SIGNING_KEY:-}"
  if [[ -z "$key_path" || ! -f "$key_path" ]]; then
    warn "FIDO_SIGNING_KEY not set or file missing; leaving payload unsigned."
    return 0
  fi
  need_cmd ssh-keygen
  if ssh-keygen -Y sign -f "$key_path" -n "${FIDO_SIGNING_NAMESPACE:-rhiz-cluster}" "$payload_file" >/dev/null 2>&1; then
    python3 - "$payload_file" "${payload_file}.sig" "$signed_file" "$key_path" <<'PY'
import json
import sys
from pathlib import Path

payload_path = Path(sys.argv[1])
sig_path = Path(sys.argv[2])
signed_path = Path(sys.argv[3])
key_path = sys.argv[4]

payload = json.loads(payload_path.read_text(encoding="utf-8"))
signature = sig_path.read_text(encoding="utf-8")
payload["handshake"]["signature"] = {
    "status": "signed",
    "keyPath": key_path,
    "signature": signature,
}
signed_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
print(signed_path)
PY
  else
    warn "ssh-keygen FIDO signing failed; leaving payload unsigned."
  fi
}

post_payload() {
  need_cmd curl
  local file_to_post="$signed_file"
  [[ -f "$file_to_post" ]] || file_to_post="$payload_file"
  local auth_args=()
  if [[ -n "$latest_token" && -f "$latest_token" ]]; then
    local token_value
    token_value="$(python3 - "$latest_token" <<'PY'
import json, sys
from pathlib import Path
data = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
print(data.get("token", ""))
PY
)"
    if [[ -n "$token_value" ]]; then
      auth_args+=(-H "Authorization: Bearer ${token_value}")
    fi
  fi
  curl -fsS -X POST \
    -H "Content-Type: application/json" \
    "${auth_args[@]}" \
    --data-binary @"$file_to_post" \
    "${HANDSHAKE_URL:-https://rhiz-arch.afrho.net/api/handshake}" > "$response_file"
  printf '%s\n' "$response_file"
}

case "$action" in
  render)
    render_payload
    sign_payload
    ;;
  check)
    [[ -f "$payload_file" ]] || die "Missing payload: $payload_file"
    python3 - "$payload_file" "$signed_file" <<'PY'
import json
import sys
from pathlib import Path

payload = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
signed = Path(sys.argv[2]).exists()
print(json.dumps({
    "rendered": True,
    "signed": signed,
    "endpoint": payload.get("handshake", {}).get("endpoint", ""),
    "mode": payload.get("handshake", {}).get("mode", ""),
}, indent=2))
PY
    ;;
  post)
    [[ -f "$payload_file" ]] || render_payload
    post_payload
    ;;
  *)
    die "Usage: $(basename "$0") [render|check|post]"
    ;;
esac
